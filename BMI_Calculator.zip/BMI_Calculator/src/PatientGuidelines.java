public interface PatientGuidelines {
    String getName();
    double getWeight();
    String getDateOfBirth();
    double getHeight();
}
